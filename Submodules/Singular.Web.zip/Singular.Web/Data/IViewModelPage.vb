﻿Namespace Data

  Public Interface IViewModelPage

    ReadOnly Property ModelNonGeneric As IViewModel

  End Interface

End Namespace
