﻿Namespace Reporting

  'Friend Class DynamicCriteria
  '  Implements Data.JS.ITypeRenderer

  '  Public Sub RenderData(Inst As Object, JW As Data.JSonWriter, Member As Data.JS.ObjectInfo.Member) Implements Data.JS.ITypeRenderer.RenderData

  '  End Sub

  '  Public Sub RenderModel(JW As Utilities.JavaScriptWriter, Member As Data.JS.ObjectInfo.Member) Implements Data.JS.ITypeRenderer.RenderModel
  '    JW.Write("CreateTypedProperty(self, '" & Member.JSonPropertyName & "', DynamicCriteriaObject, false);")
  '  End Sub

  '  Public ReadOnly Property TypeRenderingMode As Data.JS.RenderTypeOption Implements Data.JS.ITypeRenderer.TypeRenderingMode
  '    Get
  '      Return Data.JS.RenderTypeOption.RenderNoTypes
  '    End Get
  '  End Property

  '  Public ReadOnly Property RendersData As Boolean Implements Data.JS.ITypeRenderer.RendersData
  '    Get
  '      Return False
  '    End Get
  '  End Property
  'End Class

End Namespace


