﻿/// <reference path="JQuery/jquery-1.7.2.js" />
/// <reference path="Singular/KO.Bindings.js" />
/// <reference path="Singular/KO.Plugins.js" />
/// <reference path="Singular/Singular.Core.js" />
/// <reference path="Singular/Singular.Data.js" />
/// <reference path="Singular/Singular.Validation.js" />
/// <reference path="Singular/Utils.js" />
/// <reference path="Mobile/KO.Mobile.Bindings.js" />
/// <reference path="Mobile/Singular.Mobile.js" />
/// <reference path="Mobile/Singular.Mobile.Data.js" />

