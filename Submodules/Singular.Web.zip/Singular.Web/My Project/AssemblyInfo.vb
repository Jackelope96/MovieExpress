﻿Imports System
Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices
Imports System.Web.UI

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Singular.Web")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("Microsoft")>
<Assembly: AssemblyProduct("Singular.Web")>
<Assembly: AssemblyCopyright("Copyright © Microsoft 2010")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>
<Assembly: InternalsVisibleTo("Singular.MVC5, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b17eb264e552c5aeea9b1291d86495321d39e18bfd9f4e55b632ac2883bea2759566e74f8de158a23ae9ef8d8161c19f86c06466067fc53bab437956fbbdb9efa220c4ff6045841a2c13e64a065ca12d61bd45dd2d8b5c0030cf4d4741b1396d38f4d7805c2fe038405c5767b4e28c9d1b8019af97c998b7a9c95b834b40d9e3")>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("7a108864-faae-4781-90f0-a02c80ec5ef8")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>